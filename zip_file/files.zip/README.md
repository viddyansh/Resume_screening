# 🎯 ResumeRank AI — NLP-Based Resume Screening System

> An AI-powered resume screening and ranking system that uses NLP techniques
> (TF-IDF and optional Sentence-BERT) to match candidates against a job description
> and rank them by relevance.

---

## 📁 Project Structure

```
resume_screener/
├── app.py              ← Streamlit web application (main entry point)
├── run_cli.py          ← Command-line interface (batch processing)
├── parser.py           ← PDF & TXT text extraction (PyMuPDF / PyPDF2)
├── preprocessing.py    ← Text cleaning, tokenisation, lemmatisation
├── vectorizer.py       ← TF-IDF and Sentence-BERT vectorization
├── similarity.py       ← Cosine similarity computation & ranking
├── utils.py            ← Helpers: validation, chart, keyword matching
├── requirements.txt    ← Python dependencies
├── README.md           ← This file
└── sample_data/
    ├── job_description.txt      ← Sample ML Engineer JD
    ├── alice_chen_resume.txt    ← Strong match (Sr. ML Engineer)
    ├── bob_martinez_resume.txt  ← Good match (Data Scientist)
    ├── david_kim_resume.txt     ← Moderate match (MLOps Engineer)
    └── carol_williams_resume.txt← Weak match (Frontend Developer)
```

---

## 🚀 Quick Start

### 1. Clone / download the project

```bash
git clone https://github.com/yourname/resume-screener.git
cd resume-screener
```

### 2. Create a virtual environment (recommended)

```bash
python -m venv venv
# macOS / Linux
source venv/bin/activate
# Windows
venv\Scripts\activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

> **Optional:** For Sentence-BERT semantic matching (downloads ~80 MB model):
> ```bash
> pip install sentence-transformers
> ```

### 4. Download NLTK data (one-time, auto-runs on first launch)

The app auto-downloads required NLTK corpora (`stopwords`, `wordnet`, `punkt`)
on first run. If you prefer to pre-download:

```python
import nltk
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('punkt')
nltk.download('punkt_tab')
```

---

## 🌐 Run the Web App

```bash
streamlit run app.py
```

Open your browser at **http://localhost:8501**

### Web App Usage

1. **Paste** your job description in the left panel
2. **Upload** one or more resumes (PDF or TXT) in the right panel
3. Choose your **vectorization method** in the sidebar (TF-IDF or Sentence-BERT)
4. Set **Top N** candidates to display
5. Click **"🚀 Rank Candidates"**

Results include:
- Score table with rank badges and progress bars
- Bar chart of similarity scores
- Per-candidate keyword match / miss analysis
- Resume text snippets
- Full methodology explanation

---

## 💻 Run the CLI

```bash
# Rank all resumes in sample_data/ against the sample JD
python run_cli.py \
  --jd sample_data/job_description.txt \
  --resumes sample_data/ \
  --method tfidf \
  --top 5

# Single resume against a JD
python run_cli.py \
  --jd my_jd.txt \
  --resumes candidate.pdf \
  --method sbert
```

---

## 📊 Example Output (CLI)

```
  Loaded 4 resume(s). Method: TFIDF
  ────────────────────────────────────────────────────────────────────────

  ======================================================================
    RESUMERANK AI — CANDIDATE RANKING RESULTS
  ======================================================================

  🥇  RANK 1  —  alice_chen_resume.txt
       Score:  82.4%  (Excellent)
       ✅ Matched keywords: python, pytorch, bert, mlflow, sagemaker, airflow, spark, kubernetes, nlp, docker
  ────────────────────────────────────────────────────────────────────────

  🥈  RANK 2  —  david_kim_resume.txt
       Score:  61.3%  (Strong)
       ✅ Matched keywords: aws, sagemaker, docker, kubernetes, airflow, spark, mlflow, python, s3
       ❌ Missing keywords: transformer, bert, llm, neurips, pinecone
  ────────────────────────────────────────────────────────────────────────

  🥉  RANK 3  —  bob_martinez_resume.txt
       Score:  48.7%  (Good)
       ✅ Matched keywords: python, scikit-learn, nlp, docker, airflow, mlflow, sql, aws
       ❌ Missing keywords: pytorch, bert, transformer, kubernetes, vertex
  ────────────────────────────────────────────────────────────────────────

  #4  RANK 4  —  carol_williams_resume.txt
       Score:  6.1%  (Weak)
       ✅ Matched keywords: python
       ❌ Missing keywords: pytorch, bert, nlp, machine learning, aws, docker
  ────────────────────────────────────────────────────────────────────────

  Total candidates analysed: 4
  Showing top 4 results
```

---

## 🧠 Methodology

### TF-IDF (Term Frequency–Inverse Document Frequency)

```
TF(t, d)     = occurrences(t, d) / total_terms(d)
IDF(t)       = log((1 + N) / (1 + df(t))) + 1
TF-IDF(t, d) = TF(t, d) × IDF(t)
```

Documents are represented as L2-normalised sparse vectors. Common words like
*"the"* or *"is"* receive low IDF; rare domain terms like *"PyTorch"* or
*"transformer"* receive high IDF, making them strongly discriminating.

### Cosine Similarity

```
cos(θ) = (A · B) / (||A|| × ||B||)
```

Measures the angle between two vectors regardless of their magnitudes.
Range: [0, 1] (higher = more similar).

### TF-IDF vs Sentence-BERT

| Aspect | TF-IDF | Sentence-BERT |
|---|---|---|
| Representation | Sparse, high-dim | Dense, 384 dim |
| Semantics | None (bag-of-words) | Rich contextual |
| Speed | Very fast (ms) | Slower (seconds) |
| GPU required | No | Optional |
| Synonym matching | No | Yes |
| Interpretability | High | Low |
| Best for | Keyword-dense JDs | Semantic resumes |

---

## ⚙️ Technical Requirements

- **Python:** 3.10+
- **Key libraries:** scikit-learn, nltk, PyMuPDF, streamlit, matplotlib
- **Optional:** sentence-transformers (for SBERT)

---

## 🛡️ Error Handling

The system handles:
- Empty / corrupt PDF files (caught in `parser.py`)
- Unsupported file formats (validation in `utils.py`)
- Blank text after parsing (detected in `similarity.py`)
- NLTK download failures (graceful fallback)
- Missing sentence-transformers (detected by `vectorizer.is_sbert_available()`)

---

## ✨ Features

- ✅ PDF + TXT resume parsing (PyMuPDF → PyPDF2 fallback)
- ✅ Full NLP pipeline: lowercase → clean → tokenise → stopword removal → lemmatise
- ✅ TF-IDF vectorization with bigrams
- ✅ Optional Sentence-BERT semantic embeddings
- ✅ Cosine similarity ranking
- ✅ Score bar chart visualisation
- ✅ Keyword match / miss analysis per candidate
- ✅ Resume snippet preview
- ✅ Streamlit web UI + CLI
- ✅ Modular, well-commented codebase

---

## 📄 License

MIT License. Free for personal and commercial use.
